This is project for my machine learning course. We aim to help our planet
by clssifying DNA strands of aliens.

Usage:
Please refer to the notebook.
